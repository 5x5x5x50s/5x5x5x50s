The game is still running but can not touch the in-game menu and the game does not respond (sound and animation on the game runs smoothly).
Please see the screenshot.